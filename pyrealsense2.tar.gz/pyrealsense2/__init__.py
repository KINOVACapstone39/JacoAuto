# py libs (pyd/so) should be copied to pyrealsense2 folder
from .pyrealsense2 import *